<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Tentukan base URL agar link aset selalu benar
// Sesuaikan "toko_kue" dengan nama folder root project Anda di htdocs
$base_url = "/toko_kue"; 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sweet Cake</title>
    <!-- Memanggil CSS -->
    <link rel="stylesheet" href="<?= $base_url ?>/assets/style.css">
</head>
<body>

<div class="navbar">
    <div class="container">
        <?php if (isset($_SESSION['admin_id'])): ?>
            <!-- Menu Navbar untuk Admin -->
            <a href="<?= $base_url ?>/admin/index.php">Dashboard</a>
            <a href="<?= $base_url ?>/admin/produk.php">Kelola Produk</a>
            <a href="<?= $base_url ?>/admin/logout.php" style="float:right;">Logout (<?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin'); ?>)</a>
        <?php else: ?>
            <!-- Menu Navbar untuk Publik -->
            <a href="<?= $base_url ?>/index.php">Sweet Cake</a>
            <a href="<?= $base_url ?>/produk.php">Produk</a>
            <a href="<?= $base_url ?>/tentang.php">Tentang Kami</a>
            <a href="<?= $base_url ?>/auth/login.php" style="float:right;">Login Admin</a>
        <?php endif; ?>
    </div>
</div>