<div style="background-color: #333; color: white; text-align: center; padding: 20px; margin-top: 50px;">
    <p>&copy; <?= date('Y'); ?> Sweet Cake. All rights reserved.</p>
</div>

</body>
</html>