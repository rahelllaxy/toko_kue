<?php
// admin/produk.php
require_once "../includes/auth.php"; // Ini otomatis memanggil session_start()
require_once "../config/database.php";

$query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");

// Panggil Header
include "../includes/header.php";
?>

<div class="container" style="margin-top: 30px;">
    <h1>Daftar Produk</h1>
    
    <div class="card">
        <?php include "../includes/flash.php"; ?>

        <a href="tambah.php" class="btn" style="margin-bottom: 20px;">+ Tambah Produk Baru</a>

        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th style="width: 50px; text-align: center;">No</th>
                        <th style="width: 80px; text-align: center;">Gambar</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th style="width: 70px; text-align: center;">Stok</th>
                        <th style="width: 160px; text-align: center;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($query)): 
                    ?>
                    <tr>
                        <td style="text-align: center;"><?= $no++; ?></td>
                        <td style="text-align: center;">
                            <?php if ($row['gambar']): ?>
                                <img src="../uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" 
                                     alt="Gambar <?= htmlspecialchars($row['nama']); ?>" 
                                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                            <?php else: ?>
                                <span style="font-size: 12px; color: #888;">Tidak ada</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= htmlspecialchars($row['nama']); ?></strong></td>
                        <td><?= htmlspecialchars($row['kategori']); ?></td>
                        <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td style="text-align: center;"><?= $row['stok']; ?></td>
                        <td style="text-align: center;">
                            <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning" style="padding: 5px 10px; font-size: 12px;">Edit</a>
                            <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="return confirm('Hapus <?= htmlspecialchars($row['nama']); ?>?');">Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php 
// Panggil Footer
include "../includes/footer.php"; 
?>